mac-SGF-reader
==============

sgf file path defaults to Documents/sgf_files/test5.sgf.

You can use left and right keys to navigate game.

left_shift + left_arrow goes to the beginning of the game.

Currently there is no support for branches/trees

![ScreenShot](/mac_sgf_reader.png)

mac SGF reader
